# Smart Lens 0.1

SwiftUI + VisionKit document scanner for iOS 26. UI in Vietnamese.

## Features
- Scan multiple pages with Apple's document camera (automatic document edge detection and perspective correction)
- Preview pages, delete individual pages, choose Original / Enhanced / Black & White
- Export and share multi-page PDF
- No account, advertising or server required

## On Windows
1. Create a PUBLIC GitHub repository named `SmartLens` (public repositories may use standard GitHub-hosted Actions runners without billed minutes, subject to GitHub policy and runner availability).
2. Upload **all** project files and folders, including `.github/workflows/build.yml`.
3. Open the repository's Actions tab and run `Build Smart Lens`, or push a commit.
4. The workflow installs XcodeGen, generates `.xcodeproj`, and attempts an unsigned iOS Simulator build.
5. Review the Actions log. An unsigned Simulator build is NOT an installable iPhone IPA.

## Device testing and App Store
- Camera scanning requires a physical supported iPhone; it will not work in the Simulator.
- To install on a real iPhone, the app must be signed using appropriate Apple signing credentials and a compatible build environment.
- App Store/TestFlight distribution generally requires a paid Apple Developer Program membership, certificates, provisioning and App Store Connect setup.
- Replace `com.example.smartlens` with your own unique bundle identifier before signing.
- Never put Apple signing certificates, passwords, private keys, or App Store Connect API keys into the public repository. Use protected GitHub Secrets when needed.

## Limitations
- This is an MVP, not yet tested with Xcode or on an iPhone in this environment.
- No OCR, manual corner adjustment, document library, page reordering, or image size optimization yet.
- PDF is image-based. Enhancements are basic Core Image filters; quality relative to Office Lens must be measured on real documents.
- Files are generated on demand; scanned pages remain in app memory until app termination.
