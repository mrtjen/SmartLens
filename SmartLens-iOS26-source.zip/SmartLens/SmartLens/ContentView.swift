import SwiftUI
import VisionKit
import PDFKit
import CoreImage
import CoreImage.CIFilterBuiltins
import UIKit

private enum ScanFilter: String, CaseIterable, Identifiable {
    case original = "Gốc"
    case enhanced = "Rõ chữ"
    case monochrome = "Trắng đen"
    var id: String { rawValue }
}

struct ContentView: View {
    @State private var pages: [UIImage] = []
    @State private var showScanner = false
    @State private var filter: ScanFilter = .enhanced
    @State private var exportURL: URL?
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                if pages.isEmpty {
                    Spacer()
                    Image(systemName: "doc.viewfinder")
                        .font(.system(size: 76))
                        .foregroundStyle(.blue)
                    Text("Quét tài liệu thông minh")
                        .font(.title2.bold())
                    Text("Tự căn viền, làm rõ chữ và xuất PDF ngay trên iPhone.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    Spacer()
                } else {
                    HStack {
                        Text("\(pages.count) trang đã quét").font(.headline)
                        Spacer()
                        Button("Xóa tất cả", role: .destructive) {
                            pages.removeAll()
                            exportURL = nil
                        }
                    }
                    Picker("Bộ lọc", selection: $filter) {
                        ForEach(ScanFilter.allCases) { item in
                            Text(item.rawValue).tag(item)
                        }
                    }
                    .pickerStyle(.segmented)
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 140))], spacing: 12) {
                            ForEach(pages.indices, id: \.self) { index in
                                VStack(spacing: 6) {
                                    Image(uiImage: process(pages[index], using: filter))
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 190)
                                        .frame(maxWidth: .infinity)
                                        .background(Color(uiColor: .secondarySystemBackground))
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                    HStack {
                                        Text("Trang \(index + 1)")
                                        Spacer()
                                        Button(role: .destructive) {
                                            pages.remove(at: index)
                                            exportURL = nil
                                        } label: {
                                            Image(systemName: "trash")
                                        }
                                        .accessibilityLabel("Xóa trang \(index + 1)")
                                    }
                                    .font(.caption)
                                }
                            }
                        }
                    }
                }
                Button {
                    showScanner = true
                } label: {
                    Label(pages.isEmpty ? "Bắt đầu quét" : "Quét thêm trang", systemImage: "camera.viewfinder")
                        .frame(maxWidth: .infinity)
                        .padding(8)
                }
                .buttonStyle(.borderedProminent)
                .disabled(!VNDocumentCameraViewController.isSupported)

                if !pages.isEmpty {
                    Button {
                        do { exportURL = try makePDF(from: pages, filter: filter) }
                        catch { errorMessage = "Không tạo được PDF: \(error.localizedDescription)" }
                    } label: {
                        Label("Tạo PDF", systemImage: "doc.richtext")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    if let exportURL {
                        ShareLink(item: exportURL) {
                            Label("Chia sẻ / Lưu PDF", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                    }
                }
            }
            .padding()
            .navigationTitle("Smart Lens")
            .sheet(isPresented: $showScanner) {
                DocumentScanner { scanned in
                    pages.append(contentsOf: scanned)
                    exportURL = nil
                } onError: { error in
                    errorMessage = error.localizedDescription
                }
            }
            .alert("Thông báo", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("Đóng", role: .cancel) { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "")
            }
        }
    }
}

private struct DocumentScanner: UIViewControllerRepresentable {
    var onScan: ([UIImage]) -> Void
    var onError: (Error) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let controller = VNDocumentCameraViewController()
        controller.delegate = context.coordinator
        return controller
    }
    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}

    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let parent: DocumentScanner
        init(_ parent: DocumentScanner) { self.parent = parent }
        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFinishWith scan: VNDocumentCameraScan) {
            let images = (0..<scan.pageCount).map { scan.imageOfPage(at: $0) }
            controller.dismiss(animated: true) { self.parent.onScan(images) }
        }
        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            controller.dismiss(animated: true)
        }
        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFailWithError error: Error) {
            controller.dismiss(animated: true) { self.parent.onError(error) }
        }
    }
}

private let ciContext = CIContext()

private func process(_ image: UIImage, using filter: ScanFilter) -> UIImage {
    guard filter != .original, let input = CIImage(image: image) else { return image }
    let output: CIImage
    switch filter {
    case .original: return image
    case .enhanced:
        let adjustment = CIFilter.colorControls()
        adjustment.inputImage = input
        adjustment.contrast = 1.22
        adjustment.saturation = 0.85
        adjustment.brightness = 0.025
        output = adjustment.outputImage ?? input
    case .monochrome:
        let mono = CIFilter.photoEffectMono()
        mono.inputImage = input
        output = mono.outputImage ?? input
    }
    guard let cgImage = ciContext.createCGImage(output, from: output.extent) else { return image }
    return UIImage(cgImage: cgImage, scale: image.scale, orientation: image.imageOrientation)
}

private func makePDF(from pages: [UIImage], filter: ScanFilter) throws -> URL {
    let document = PDFDocument()
    for (index, image) in pages.enumerated() {
        guard let page = PDFPage(image: process(image, using: filter)) else {
            throw NSError(domain: "SmartLens", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Không thể chuyển trang \(index + 1) thành PDF"])
        }
        document.insert(page, at: index)
    }
    let url = FileManager.default.temporaryDirectory
        .appendingPathComponent("SmartLens-\(UUID().uuidString).pdf")
    guard document.write(to: url) else {
        throw NSError(domain: "SmartLens", code: 2,
                      userInfo: [NSLocalizedDescriptionKey: "Không ghi được tệp PDF"])
    }
    return url
}
