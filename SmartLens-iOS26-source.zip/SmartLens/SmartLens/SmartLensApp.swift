import SwiftUI

@main
struct SmartLensApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
